build_info = "{\"build-info\" : [{\"build-version\" : \"4.1.1.0\", \"build-time\" : \"2018-03-08 14:16:54.188227\", \"build-user\" : \"root\", \"build-hostname\" : \"devstack-test-2\", ";
